package net.radionica.emisia.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int _id;
	@Column(name = "firstname")
	private String _firstname;
	@Column(name = "lastname")
	private String _lastname;
	@Column(name = "username", unique = true)
	private String _username;
	@Column(name = "password")
	private String _password;
	@Column(name = "email", unique = true)
	private String _email;
	@Column(name = "role")
	private String _role;

	public int getId() {
		return _id;
	}

	public void setId(int id) {
		_id = id;
	}

	public String getFirstname() {
		return _firstname;
	}

	public void setFirstname(String firstname) {
		_firstname = firstname;
	}

	public String getLastname() {
		return _lastname;
	}

	public void setLastname(String lastname) {
		_lastname = lastname;
	}

	public String getUsername() {
		return _username;
	}

	public void setUsername(String username) {
		_username = username;
	}

	public String getPassword() {
		return _password;
	}

	public void setPassword(String password) {
		_password = password;
	}

	public String getEmail() {
		return _email;
	}

	public void setEmail(String email) {
		_email = email;
	}

	public String getRole() {
		return _role;
	}

	public void setRole(String role) {
		_role = role;
	}

	public String toString() {
		return "First name and second name of user: " + _firstname + " " + _lastname + "\nUsername and email of user: "
				+ _username + " " + _email + "\nrole of user: " + _role;
	}

}
