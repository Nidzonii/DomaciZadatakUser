package net.radionica.emisia.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import net.radionica.emisia.model.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {

	User findBy_email(String email);

	User findBy_username(String username);

}
