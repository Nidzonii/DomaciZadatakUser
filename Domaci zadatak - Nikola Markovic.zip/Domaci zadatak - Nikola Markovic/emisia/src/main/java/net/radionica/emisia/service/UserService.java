package net.radionica.emisia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.radionica.emisia.dao.UserRepository;
import net.radionica.emisia.model.User;

@Service
public class UserService {
	@Autowired
	UserRepository _user;

	public UserService(UserRepository user) {
		super();
		_user = user;
	}

	public UserRepository getUser() {
		return _user;
	}

	public User findUserById(int id) {
		return getUser().findById(id).get();
	}

	public User findByEmail(String email) {
		return getUser().findBy_email(email);
	}

	public User findByUsername(String username) {
		return getUser().findBy_username(username);
	}

	public User saveAllUsers(User usr) {
		return getUser().save(usr);
	}
}
