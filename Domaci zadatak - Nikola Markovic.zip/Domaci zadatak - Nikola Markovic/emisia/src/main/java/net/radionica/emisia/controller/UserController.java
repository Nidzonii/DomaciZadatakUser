package net.radionica.emisia.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import net.radionica.emisia.model.User;
import net.radionica.emisia.service.UserService;

@RestController
public class UserController {

	@Autowired
	UserService _usr;

	public UserService getUsr() {
		return _usr;
	}

	@RequestMapping(value = "/user/id/{json}", method = RequestMethod.GET)
	public String findUserByID(@PathVariable("json") int id) {
		User user = getUsr().findUserById(id);
		return user.toString();
	}

	@RequestMapping(value = "/user/username/{json}", method = RequestMethod.GET)
	public String findUserByUsername(@PathVariable("json") String usrname) {
		User user = getUsr().findByUsername(usrname);
		return user.toString();
	}

	@RequestMapping(value = "/user/email/{json}", method = RequestMethod.GET)
	public String findUserByEmail(@PathVariable("json") String email) {
		User user = getUsr().findByEmail(email);
		return user.toString();
	}

	@RequestMapping(value = "/user/all", method = RequestMethod.POST)
	public void saveUser(@RequestBody User usr) {
		getUsr().saveAllUsers(usr);
	}

}
